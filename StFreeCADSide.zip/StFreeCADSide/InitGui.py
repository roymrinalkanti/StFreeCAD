FreeCADGui.doCommand("import Web")
FreeCADGui.doCommand("Web.startServer('127.0.0.1',54321)")